import Foundation
import AVFoundation
import os

enum MetadataReader {

    struct Metadata {
        var title: String?
        var artist: String?
        var album: String?
        var duration: Double?
        var artworkData: Data?
    }

    static func read(from fileURL: URL) -> Metadata {
        var result = Metadata()
        let sema = DispatchSemaphore(value: 0)

        Task {
            result = await readAsync(from: fileURL)
            sema.signal()
        }

        sema.wait()
        return result
    }

    private static func readAsync(from fileURL: URL) async -> Metadata {
        var out = Metadata()

        let asset = AVURLAsset(url: fileURL)

        do {
            let dur = try await asset.load(.duration)
            let seconds = CMTimeGetSeconds(dur)
            if seconds.isFinite, seconds > 0 {
                out.duration = seconds
            }
        } catch {
            // ignore
        }

        let items: [AVMetadataItem]
        do {
            items = try await asset.load(.commonMetadata)
        } catch {
            os_log("MetadataReader: load commonMetadata failed: %@", type: .debug, String(describing: error))
            return out
        }

        if let item = AVMetadataItem.metadataItems(from: items, filteredByIdentifier: .commonIdentifierTitle).first {
            out.title = await loadString(from: item)
        }

        if let item = AVMetadataItem.metadataItems(from: items, filteredByIdentifier: .commonIdentifierArtist).first {
            out.artist = await loadString(from: item)
        }

        if let item = AVMetadataItem.metadataItems(from: items, filteredByIdentifier: .commonIdentifierAlbumName).first {
            out.album = await loadString(from: item)
        }

        if let item = AVMetadataItem.metadataItems(from: items, filteredByIdentifier: .commonIdentifierArtwork).first {
            out.artworkData = await loadArtworkData(from: item)
        }

        return out
    }

    private static func loadString(from item: AVMetadataItem) async -> String? {
        if let s = try? await item.load(.stringValue) {
            let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            return t.isEmpty ? nil : t
        }

        if let v = try? await item.load(.value),
           let s = v as? String {
            let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            return t.isEmpty ? nil : t
        }

        return nil
    }

    private static func loadArtworkData(from item: AVMetadataItem) async -> Data? {
        if let d = try? await item.load(.dataValue) {
            return d.isEmpty ? nil : d
        }

        if let v = try? await item.load(.value),
           let d = v as? Data {
            return d.isEmpty ? nil : d
        }

        return nil
    }
}
