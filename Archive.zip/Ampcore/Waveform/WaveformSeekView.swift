import SwiftUI

struct WaveformSeekView: View {

    let peaks: [Float]
    let duration: Double
    let currentTime: Double
    let onSeek: (Double) -> Void

    @State private var isDragging = false

    private let barWidth: CGFloat = 2
    private let barSpacing: CGFloat = 1

    var body: some View {
        GeometryReader { geo in
            Canvas { ctx, size in
                let totalWidth = CGFloat(peaks.count) * (barWidth + barSpacing)
                let offsetX = max(0, (totalWidth - size.width) * progress)

                ctx.translateBy(x: -offsetX, y: 0)

                for (i, peak) in peaks.enumerated() {
                    let x = CGFloat(i) * (barWidth + barSpacing)
                    let h = max(1, CGFloat(peak) * size.height)
                    let y = (size.height - h) / 2

                    let rect = CGRect(x: x, y: y, width: barWidth, height: h)
                    ctx.fill(Path(rect), with: .color(.black))
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        isDragging = true
                        let p = clamp(value.location.x / geo.size.width, 0, 1)
                        onSeek(p * duration)
                    }
                    .onEnded { _ in
                        isDragging = false
                    }
            )
        }
    }

    private var progress: CGFloat {
        guard duration > 0 else { return 0 }
        return clamp(currentTime / duration, 0, 1)
    }

    private func clamp<T: Comparable>(_ v: T, _ a: T, _ b: T) -> T {
        min(max(v, a), b)
    }
}
