import Foundation

final class WaveformCache {

    static let shared = WaveformCache()

    private let cacheURL: URL
    private let ioQueue = DispatchQueue(label: "ampcore.waveform.cache.io", qos: .utility)

    private init() {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        cacheURL = base.appendingPathComponent("WaveformCache", isDirectory: true)
        try? FileManager.default.createDirectory(at: cacheURL, withIntermediateDirectories: true)
    }

    func loadPeaks(for key: String) async -> [Float]? {
        await withCheckedContinuation { continuation in
            ioQueue.async {
                let url = self.cacheURL.appendingPathComponent(key)
                guard let data = try? Data(contentsOf: url) else {
                    continuation.resume(returning: nil)
                    return
                }

                let count = data.count / MemoryLayout<Float>.size
                let peaks = data.withUnsafeBytes { ptr -> [Float] in
                    let buf = ptr.bindMemory(to: Float.self)
                    return Array(buf.prefix(count))
                }

                continuation.resume(returning: peaks)
            }
        }
    }

    func savePeaks(_ peaks: [Float], for key: String) async {
        await withCheckedContinuation { continuation in
            ioQueue.async {
                let url = self.cacheURL.appendingPathComponent(key)
                let data = peaks.withUnsafeBufferPointer { Data(buffer: $0) }
                try? data.write(to: url, options: [.atomic])
                continuation.resume()
            }
        }
    }

    func clear() async {
        await withCheckedContinuation { continuation in
            ioQueue.async {
                try? FileManager.default.removeItem(at: self.cacheURL)
                try? FileManager.default.createDirectory(at: self.cacheURL, withIntermediateDirectories: true)
                continuation.resume()
            }
        }
    }
}
