import Foundation
import AVFoundation
import Accelerate

enum WaveformBuilder {
    nonisolated static let bucketCount: Int = 240

    static func buildPeaks(from url: URL, bucketCount: Int = WaveformBuilder.bucketCount) async throws -> [Float] {
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .audio).first else { return [] }

        let reader = try AVAssetReader(asset: asset)
        let settings: [String: Any] = [
            AVFormatIDKey: kAudioFormatLinearPCM,
            AVLinearPCMIsFloatKey: true,
            AVLinearPCMBitDepthKey: 32,
            AVLinearPCMIsNonInterleaved: false,
            AVLinearPCMIsBigEndianKey: false
        ]

        let output = AVAssetReaderTrackOutput(track: track, outputSettings: settings)
        output.alwaysCopiesSampleData = false
        reader.add(output)
        reader.startReading()

        var all: [Float] = []
        all.reserveCapacity(1_000_000)

        while true {
            guard let sb = output.copyNextSampleBuffer(),
                  let block = CMSampleBufferGetDataBuffer(sb) else { break }

            let len = CMBlockBufferGetDataLength(block)
            var data = Data(count: len)
            data.withUnsafeMutableBytes { dst in
                _ = CMBlockBufferCopyDataBytes(block, atOffset: 0, dataLength: len, destination: dst.baseAddress!)
            }

            let n = len / MemoryLayout<Float>.size
            data.withUnsafeBytes { ptr in
                let buf = ptr.bindMemory(to: Float.self)
                all.append(contentsOf: buf[0..<n])
            }
                        CMSampleBufferInvalidate(sb)
        }

        if reader.status == .failed {
            throw reader.error ?? NSError(domain: "WaveformBuilder", code: -1, userInfo: [NSLocalizedDescriptionKey: "Waveform reader failed"])
        }

        guard !all.isEmpty else { return [] }

        // Use RMS per bucket (not peak) to avoid falsely high bars in quiet tails.
        var absAll = [Float](repeating: 0, count: all.count)
        vDSP_vabs(all, 1, &absAll, 1, vDSP_Length(all.count))

        let buckets = max(16, bucketCount)
        let step = Double(absAll.count) / Double(buckets)

        var values = [Float](repeating: 0, count: buckets)

        absAll.withUnsafeBufferPointer { ptr in
            guard let base = ptr.baseAddress else { return }
            for i in 0..<buckets {
                let start = Int(Double(i) * step)
                let end = min(absAll.count, Int(Double(i + 1) * step))
                if start >= end {
                    values[i] = 0
                    continue
                }

                var rms: Float = 0
                vDSP_rmsqv(base.advanced(by: start), 1, &rms, vDSP_Length(end - start))
                values[i] = rms
            }
        }

        values = smooth(values)

        // Robust normalization: 99th percentile.
        let ref = percentile(values, p: 0.99)
        guard ref > 0 else { return values }

        var denom = ref * 1.15
        var norm = [Float](repeating: 0, count: values.count)
        vDSP_vsdiv(values, 1, &denom, &norm, 1, vDSP_Length(values.count))

        // Clamp to [0, 1].
        var one: Float = 1
        var zero: Float = 0
        vDSP_vclip(norm, 1, &zero, &one, &norm, 1, vDSP_Length(norm.count))
        return norm
    }

    private static func smooth(_ v: [Float]) -> [Float] {
        guard v.count >= 3 else { return v }
        var out = v
        for i in 1..<(v.count - 1) {
            out[i] = (v[i - 1] + v[i] + v[i + 1]) / 3
        }
        return out
    }

    private static func percentile(_ data: [Float], p: Double) -> Float {
        guard !data.isEmpty else { return 1 }
        let clamped = min(max(p, 0), 1)
        let sorted = data.sorted()
        let idx = Int((Double(sorted.count - 1) * clamped).rounded(.toNearestOrAwayFromZero))
        return sorted[min(max(idx, 0), sorted.count - 1)]
    }
}
