import SwiftUI
import CoreText
import UIKit

enum Typography {

    static func font(_ style: Font.TextStyle, settings: AppSettings) -> Font {
        let size = pointSize(for: style)

        switch settings.fontChoice {
        case .system:
            let base = Font.system(size: size, weight: .regular)
            return settings.boldText ? base.weight(.bold) : base

        case .alternative:
            let psName = alternativePostScriptName(preferBold: settings.boldText) ?? "BaAQUA_C"
            return Font.custom(psName, size: size)
        }
    }

    // MARK: - Alternative font

    private static var didRegister = false
    private static var cachedRegularPS: String?
    private static var cachedBoldPS: String?

    private static func alternativePostScriptName(preferBold: Bool) -> String? {
        if !didRegister {
            registerAlternativeFontIfNeeded()
            didRegister = true
        }

        if preferBold {
            if let cachedBoldPS { return cachedBoldPS }
            if let bold = findPostScriptName(isBold: true) {
                cachedBoldPS = bold
                return bold
            }
            // Fallback: try synthetic bold via UIFont descriptor traits
            if let reg = alternativePostScriptName(preferBold: false),
               let synthetic = syntheticBoldPostScriptName(from: reg) {
                cachedBoldPS = synthetic
                return synthetic
            }
            return alternativePostScriptName(preferBold: false)
        } else {
            if let cachedRegularPS { return cachedRegularPS }
            if let reg = findPostScriptName(isBold: false) {
                cachedRegularPS = reg
                return reg
            }
            return nil
        }
    }

    private static func registerAlternativeFontIfNeeded() {
        guard let url = Bundle.main.url(forResource: "BaAQUA_C", withExtension: "ttf") else { return }
        CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
    }

    private static func findPostScriptName(isBold: Bool) -> String? {
        guard let url = Bundle.main.url(forResource: "BaAQUA_C", withExtension: "ttf"),
              let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor],
              !descriptors.isEmpty else {
            return nil
        }

        // Some single-file fonts expose multiple faces; prefer Bold if available.
        var best: (name: String, score: Double)?

        for d in descriptors {
            guard let ps = CTFontDescriptorCopyAttribute(d, kCTFontNameAttribute) as? String else { continue }

            let traits = (CTFontDescriptorCopyAttribute(d, kCTFontTraitsAttribute) as? [CFString: Any]) ?? [:]
            let weight = (traits[kCTFontWeightTrait] as? Double) ?? 0.0
            let sym = (traits[kCTFontSymbolicTrait] as? UInt32) ?? 0
            let hasBoldTrait = (sym & CTFontSymbolicTraits.boldTrait.rawValue) != 0

            let nameLower = ps.lowercased()
            let nameSaysBold = nameLower.contains("bold") || nameLower.contains("bd")

            let isActuallyBold = hasBoldTrait || nameSaysBold || weight >= 0.35

            let ok = isBold ? isActuallyBold : !isActuallyBold
            guard ok else { continue }

            // Score: prefer explicit Bold naming / stronger weight
            let score = (nameSaysBold ? 2.0 : 0.0) + (hasBoldTrait ? 1.0 : 0.0) + weight
            if best == nil || score > best!.score {
                best = (ps, score)
            }
        }

        return best?.name
    }

    private static func syntheticBoldPostScriptName(from postScriptName: String) -> String? {
        // Create a synthetic bold font and register it in memory (UIFont-based).
        guard let base = UIFont(name: postScriptName, size: 17) else { return nil }
        let desc = base.fontDescriptor.withSymbolicTraits([.traitBold]) ?? base.fontDescriptor
        let bold = UIFont(descriptor: desc, size: 17)

        // UIFont may return a different PostScript name after applying traits.
        return bold.fontName
    }

    // MARK: - Sizes

    private static func pointSize(for style: Font.TextStyle) -> CGFloat {
        switch style {
        case .largeTitle: return 34
        case .title: return 28
        case .title2: return 22
        case .title3: return 20
        case .headline: return 17
        case .subheadline: return 15
        case .body: return 17
        case .callout: return 16
        case .footnote: return 13
        case .caption: return 12
        case .caption2: return 11
        @unknown default: return 17
        }
    }
}
