import SwiftUI
import Combine

struct LookFeelSettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    
    var body: some View {
        Form {
            Section("Theme") {
                Picker("Theme", selection: Binding(
                    get: { settings.theme },
                    set: { settings.theme = $0 }
                )) {
                    ForEach(AppSettings.Theme.allCases) { t in
                        Text(t.title).tag(t)
                    }
                }
            }
            
            Section("Font") {
                Picker("Font", selection: Binding(
                    get: { settings.fontChoice },
                    set: { settings.fontChoice = $0 }
                )) {
                    ForEach(AppSettings.FontChoice.allCases) { f in
                        Text(f.title).tag(f)
                    }
                }
                
                Toggle("Bold Text", isOn: $settings.boldText)
                    .disabled(settings.fontChoice == .alternative)
                    .opacity(settings.fontChoice == .alternative ? 0.45 : 1)
            }
        }
        .navigationTitle("Look & Feel")
        .onChange(of: settings.fontChoice) { _, newValue in
            if newValue == .alternative {
                settings.boldText = false
            }
        }
    }
}
