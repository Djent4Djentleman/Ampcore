import SwiftUI

struct EQView: View {

    @EnvironmentObject private var env: AppEnvironment

    private let ink = Color.black

    @State private var eqEnabled = false
    @State private var toneEnabled = false
    @State private var limitEnabled = false

    @State private var preset: Preset = .flat

    // Pre + 31..8K
    @State private var bands: [EQBandUI] = []

    @State private var bass: Double = 0
    @State private var treble: Double = 0

    @State private var scrollProxy: ScrollViewProxy?
    @State private var focusedIndex: Int = 0

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                topRow
                slidersRow

                responsePanel
                    .padding(.horizontal, 16)

                bottomPanel
                    .padding(.horizontal, 16)
                    .padding(.bottom, 10)

                Spacer(minLength: 0)
            }
            .padding(.top, 10)
            .navigationTitle("EQ")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                // Default OFF
                eqEnabled = false
                toneEnabled = false
                limitEnabled = false
                bass = 0
                treble = 0

                env.player.eqEnabled = false

                // Engine -> UI
                bands = uiBands(from: env.player.eqBands)

                preset = .flat
                applyPreset(.flat)
                pushBandsToEngine()
            }
            .onChange(of: bands) { _, _ in
                pushBandsToEngine()
            }
            .onChange(of: eqEnabled) { _, newValue in
                if !newValue {
                    toneEnabled = false
                    limitEnabled = false
                    bass = 0
                    treble = 0
                }
                env.player.eqEnabled = newValue
                if newValue {
                    pushBandsToEngine()
                }
            }
            .onChange(of: preset) { _, newPreset in
                applyPreset(newPreset)
                pushBandsToEngine()
            }
        }
    }

    // MARK: - Engine sync

    private func pushBandsToEngine() {
        env.player.applyEQBands(engineBands(from: bands))
    }

    private func engineBands(from ui: [EQBandUI]) -> [EQBand] {
        ui.map { EQBand(label: $0.label, value: Float($0.value), min: Float($0.min), max: Float($0.max)) }
    }

    private func uiBands(from engine: [EQBand]) -> [EQBandUI] {
        engine.map { EQBandUI(label: $0.label, value: Double($0.value), min: Double($0.min), max: Double($0.max)) }
    }

    // MARK: - Top

    private var topRow: some View {
        HStack(spacing: 12) {
            Text("EQ")
                .font(.headline)
                .foregroundStyle(ink)

            Spacer()

            Menu {
                Picker("Preset", selection: $preset) {
                    ForEach(Preset.allCases) { p in
                        Text(p.title).tag(p)
                    }
                }
            } label: {
                HStack(spacing: 8) {
                    Text(preset.title)
                        .foregroundStyle(ink)
                        .font(.subheadline.weight(.semibold))
                        .lineLimit(1)
                        .minimumScaleFactor(0.85)

                    Image(systemName: "chevron.down")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(ink.opacity(0.7))
                }
                .frame(width: 210, alignment: .center)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(.thinMaterial, in: Capsule())
                .overlay(Capsule().stroke(ink.opacity(0.25), lineWidth: 1))
            }
        }
        .padding(.horizontal, 16)
    }

    // MARK: - Sliders

    private var slidersRow: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: true) {
                HStack(spacing: 12) {
                    ForEach(Array(bands.enumerated()), id: \.offset) { idx, _ in
                        VStack(spacing: 8) {
                            VerticalEQSlider(
                                value: Binding(
                                    get: { bands[idx].value },
                                    set: { v in
                                        bands[idx].value = v
                                        focusedIndex = idx
                                    }
                                ),
                                range: bands[idx].min...bands[idx].max,
                                enabled: eqEnabled,
                                ink: ink
                            )
                            .frame(width: 46, height: 210)

                            Text(bands[idx].label)
                                .font(.caption2.weight(.semibold))
                                .foregroundStyle(ink.opacity(eqEnabled ? 0.9 : 0.35))

                            Text(String(format: "%.1f", bands[idx].value))
                                .font(.caption2)
                                .foregroundStyle(ink.opacity(eqEnabled ? 0.65 : 0.25))
                        }
                        .frame(width: 54)
                        .id(idx)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 2)
            }
            .onAppear { scrollProxy = proxy }
        }
    }

    // MARK: - Response panel + overlay scroller

    private var responsePanel: some View {
        let shape = RoundedRectangle(cornerRadius: 18, style: .continuous)

        return ZStack {
            shape
                .fill(.thinMaterial)
                .overlay(shape.stroke(ink.opacity(0.12), lineWidth: 1))

            responseCurve
                .padding(.horizontal, 18)

            glassScroller
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
        }
        .frame(height: 74)
        .opacity(0.95)
        .clipShape(shape)
    }

    private var responseCurve: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h = geo.size.height
            let points = curvePoints(width: w, height: h)

            Path { p in
                guard let first = points.first else { return }
                p.move(to: first)
                for pt in points.dropFirst() { p.addLine(to: pt) }
            }
            .stroke(ink, lineWidth: 2.2)
        }
    }

    private func curvePoints(width: CGFloat, height: CGFloat) -> [CGPoint] {
        let n = max(bands.count, 2)
        let minV = bands.map(\.min).min() ?? -12
        let maxV = bands.map(\.max).max() ?? 12

        func y(for v: Double) -> CGFloat {
            let denom = (maxV - minV == 0) ? 1 : (maxV - minV)
            let t = (v - minV) / denom
            return (1 - CGFloat(t)) * height
        }

        var pts: [CGPoint] = []
        pts.reserveCapacity(n)

        for i in 0..<n {
            let x = CGFloat(i) / CGFloat(n - 1) * width
            let vv = (i < bands.count) ? bands[i].value : 0
            pts.append(CGPoint(x: x, y: y(for: vv)))
        }

        if pts.count > 2 {
            var smooth = pts
            for i in 1..<(pts.count - 1) {
                let yv = (pts[i-1].y + pts[i].y * 2 + pts[i+1].y) / 4
                smooth[i] = CGPoint(x: pts[i].x, y: yv)
            }
            return smooth
        }
        return pts
    }

    private var glassScroller: some View {
        GeometryReader { geo in
            let w = geo.size.width
            let h: CGFloat = 44
            let count = max(bands.count, 1)

            let knobW = max(90, w * 0.28)
            let step = (w - knobW) / CGFloat(max(count - 1, 1))
            let x = CGFloat(focusedIndex) * step

            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 16, style: .continuous)
                        .stroke(ink.opacity(0.06), lineWidth: 1)
                )
                .frame(height: h)
                .overlay(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .fill(ink.opacity(0.03))
                        .background(.ultraThinMaterial)
                        .frame(width: knobW, height: 38)
                        .offset(x: x)
                        .animation(.easeOut(duration: 0.12), value: focusedIndex)
                }
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { g in
                            let p = min(max(g.location.x / max(w, 1), 0), 1)
                            let idx = Int((p * CGFloat(count - 1)).rounded())
                            let clamped = max(0, min(count - 1, idx))
                            guard clamped != focusedIndex else { return }
                            focusedIndex = clamped

                            if let proxy = scrollProxy {
                                withAnimation(.easeOut(duration: 0.12)) {
                                    proxy.scrollTo(clamped, anchor: .center)
                                }
                            }
                        }
                )
                .opacity(eqEnabled ? 1.0 : 0.55)
        }
        .frame(height: 44)
    }

    // MARK: - Bottom panel

    private var bottomPanel: some View {
        HStack(spacing: 12) {
            VStack(spacing: 10) {
                modePillButton(title: "Equ", isOn: eqEnabled, isEnabled: true) {
                    withAnimation(.easeInOut(duration: 0.18)) { eqEnabled.toggle() }
                }

                modePillButton(title: "Tone", isOn: eqEnabled && toneEnabled, isEnabled: eqEnabled) {
                    guard eqEnabled else { return }
                    withAnimation(.easeInOut(duration: 0.18)) { toneEnabled.toggle() }
                }

                modePillButton(title: "Limit", isOn: eqEnabled && limitEnabled, isEnabled: eqEnabled) {
                    guard eqEnabled else { return }
                    withAnimation(.easeInOut(duration: 0.18)) { limitEnabled.toggle() }
                }
            }
            .frame(width: 60)

            VStack(spacing: 10) {
                HStack(spacing: 18) {
                    ToneKnob(title: "Bass", value: $bass, enabled: eqEnabled && toneEnabled, ink: ink)
                    ToneKnob(title: "Treble", value: $treble, enabled: eqEnabled && toneEnabled, ink: ink)
                }
            }
        }
    }

    private func modePillButton(title: String, isOn: Bool, isEnabled: Bool = true, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Capsule()
                    .fill(Color.clear)
                    .frame(width: 34, height: 66)
                    .overlay(
                        Capsule()
                            .stroke(ink.opacity(isEnabled ? 0.75 : 0.35), lineWidth: 1)
                    )
                    .overlay(
                        Rectangle()
                            .fill(ink.opacity(isEnabled ? 0.85 : 0.35))
                            .frame(width: 18, height: 2)
                    )
                    .overlay(
                        Capsule()
                            .fill(ink.opacity(isOn ? 0.10 : 0.0))
                    )

                Text(title)
                    .font(.system(size: 11, weight: .regular))
                    .foregroundStyle(ink.opacity(isEnabled ? 0.85 : 0.35))
            }
            .frame(width: 60)
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled)
    }

    // MARK: - Presets

    private func applyPreset(_ p: Preset) {
        let v: [Double]
        switch p {
        case .flat:
            v = [0, 0,0,0,0,0,0,0,0,0]
        case .rock:
            v = [0, 3,2,1,0.5,-0.5,1.5,3,1,0.5]
        case .bassBoost:
            v = [2, 6,5,3,1,0,-1,-1,-1,-1]
        case .trebleBoost:
            v = [0, -1,-1,0,1,2,4,5,6,5]
        case .vShape:
            v = [0, 4,3,1,-1,-1,1,3,4,3]
        case .vocal:
            v = [0, -2,-1,1,3,3,2,1,0,0]
        case .metal:
            v = [0, 4,3,0,-1,1,3,4,2,1]
        case .dance:
            v = [0, 5,4,2,0,-1,1,3,4,3]
        case .acoustic:
            v = [0, -1,0,1,2,2,1,0,-1,-1]
        }

        for i in bands.indices {
            bands[i].value = v[safe: i] ?? 0
        }
    }
}

// MARK: - Models

private struct EQBandUI: Equatable {
    var label: String
    var value: Double
    var min: Double
    var max: Double
}

private enum Preset: String, CaseIterable, Identifiable {
    case flat, rock, bassBoost, trebleBoost, vShape, vocal, metal, dance, acoustic
    var id: String { rawValue }
    var title: String {
        switch self {
        case .flat: return "Flat"
        case .rock: return "Rock"
        case .bassBoost: return "Bass Boost"
        case .trebleBoost: return "Treble Boost"
        case .vShape: return "V-Shape"
        case .vocal: return "Vocal"
        case .metal: return "Metal"
        case .dance: return "Dance"
        case .acoustic: return "Acoustic"
        }
    }
}

// MARK: - Vertical slider

private struct VerticalEQSlider: View {
    @Binding var value: Double
    let range: ClosedRange<Double>
    let enabled: Bool
    let ink: Color

    private let handleH: CGFloat = 44

    var body: some View {
        GeometryReader { geo in
            let h = geo.size.height
            let w = geo.size.width

            ZStack {
                Capsule()
                    .fill(ink.opacity(0.18))
                    .frame(width: 3)

                Rectangle()
                    .fill(ink.opacity(0.18))
                    .frame(width: 26, height: 1)

                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(Color.white.opacity(0.78))
                    .overlay(
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .stroke(ink.opacity(0.55), lineWidth: 1)
                    )
                    .frame(width: w, height: handleH)
                    .overlay(
                        Capsule()
                            .fill(ink.opacity(0.55))
                            .frame(width: 18, height: 4)
                    )
                    .position(x: w / 2, y: yPos(for: value, height: h))
                    .shadow(radius: 2, y: 1)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .contentShape(Rectangle())
            .highPriorityGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { g in
                        guard enabled else { return }
                        let y = min(max(g.location.y, handleH / 2), h - handleH / 2)
                        value = valueFrom(y: y, height: h)
                    }
            )
            .opacity(enabled ? 1.0 : 0.40)
        }
    }

    private func yPos(for v: Double, height: CGFloat) -> CGFloat {
        let denom = (range.upperBound - range.lowerBound == 0) ? 1 : (range.upperBound - range.lowerBound)
        let t = (v - range.lowerBound) / denom
        let raw = (1 - CGFloat(t)) * height
        return min(max(raw, handleH / 2), height - handleH / 2)
    }

    private func valueFrom(y: CGFloat, height: CGFloat) -> Double {
        let usable = max(height - handleH, 1)
        let t = 1 - Double((y - handleH / 2) / usable)
        return range.lowerBound + t * (range.upperBound - range.lowerBound)
    }
}

// MARK: - Tone knob

private struct ToneKnob: View {
    let title: String
    @Binding var value: Double
    let enabled: Bool
    let ink: Color

    private let range: ClosedRange<Double> = -100...100

    var body: some View {
        VStack(spacing: 6) {
            HStack {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(ink.opacity(enabled ? 0.9 : 0.35))
                Spacer()
                Text("\(Int(value))%")
                    .font(.caption2)
                    .foregroundStyle(ink.opacity(enabled ? 0.65 : 0.25))
            }

            ZStack {
                Circle().fill(.thinMaterial)
                Circle().stroke(ink.opacity(0.22), lineWidth: 1)

                Rectangle()
                    .fill(ink.opacity(enabled ? 0.75 : 0.25))
                    .frame(width: 4, height: 22)
                    .offset(y: -22)
                    .rotationEffect(.degrees(angle))
            }
            .frame(width: 110, height: 110)
            .contentShape(Circle())
            .highPriorityGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { g in
                        guard enabled else { return }
                        let delta = -Double(g.translation.height) * 0.6
                        value = clamp(value + delta, range)
                    }
            )
            .opacity(enabled ? 1.0 : 0.55)
        }
    }

    private var angle: Double {
        let denom = (range.upperBound - range.lowerBound == 0) ? 1 : (range.upperBound - range.lowerBound)
        let t = (value - range.lowerBound) / denom
        return -135 + t * 270
    }

    private func clamp(_ v: Double, _ r: ClosedRange<Double>) -> Double {
        min(max(v, r.lowerBound), r.upperBound)
    }
}

private extension Array {
    subscript(safe idx: Int) -> Element? {
        guard indices.contains(idx) else { return nil }
        return self[idx]
    }
}
