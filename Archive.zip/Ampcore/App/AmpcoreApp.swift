import SwiftUI
import CoreText
import CoreData

@main
struct AmpcoreApp: App {

    init() {
        registerFonts()
    }

    let persistence = PersistenceController.shared
    let env = AppEnvironment.shared

        private func registerFonts() {
        guard let url = Bundle.main.url(forResource: "BaAQUA_C", withExtension: "ttf") else { return }
        CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(env.settings)
                .environment(\.managedObjectContext, persistence.container.viewContext)
                .environmentObject(env)
                .onAppear {
                    // Inject CoreData context into player
                    env.player.managedObjectContext = persistence.container.viewContext
                    env.autoScanIfNeeded(context: persistence.container.viewContext)
                }
        }
    }
}
