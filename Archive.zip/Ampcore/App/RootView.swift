import SwiftUI
import UIKit

struct RootView: View {
    @EnvironmentObject private var env: AppEnvironment
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.colorScheme) private var envScheme

    private enum Tab: Equatable {
        case library
        case player
        case search
        case settings
    }

    @State private var tab: Tab = .player

    private let barHeight: CGFloat = 76
    private let barCorner: CGFloat = 28

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .bottom) {
                content
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .safeAreaInset(edge: .bottom) {
                        Color.clear.frame(height: barHeight + max(12, geo.safeAreaInsets.bottom) + 10)
                    }

                bottomBar(isLight: cs == .light)
                    .padding(.horizontal, 14)
                    .padding(.bottom, max(6, geo.safeAreaInsets.bottom))
                    .zIndex(1000)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(appBackground)
            .onAppear {
                tab = .player
                env.navigation.screen = .player
            }
            .onChange(of: env.navigation.screen) { _, newValue in
                switch newValue {
                case .library:
                    tab = .library
                case .player:
                    tab = .player
                }
            }
        }
        .preferredColorScheme(cs)
        .environment(\.font, Typography.font(.body, settings: settings))
    }

    // MARK: - Content

    @ViewBuilder
    private var content: some View {
        switch tab {
        case .library:
            NavigationStack { LibraryHomeView() }

        case .player:
            NavigationStack { PlayerView() }

        case .search:
            NavigationStack {
                SearchView()
                    .navigationTitle("")
                    .navigationBarTitleDisplayMode(.inline)
            }

        case .settings:
            NavigationStack { SettingsRootView() }
        }
    }

    // MARK: - Bottom bar

    private func bottomBar(isLight: Bool) -> some View {
        let bg = isLight ? Color.black.opacity(0.10) : Color.white.opacity(0.12)
        let stroke = isLight ? Color.black.opacity(0.12) : Color.white.opacity(0.14)
        let shadow = isLight ? Color.black.opacity(0.18) : Color.black.opacity(0.35)

        return HStack(spacing: 30) {
            barButton(icon: "music.note.list", isActive: tab == .library) {
                tab = .library
                env.navigation.screen = .library
            }

            barButton(icon: "play.circle.fill", isActive: tab == .player) {
                tab = .player
                env.navigation.screen = .player
            }

            barButton(icon: "magnifyingglass", isActive: tab == .search) {
                tab = .search
            }

            barButton(icon: "gearshape", isActive: tab == .settings) {
                tab = .settings
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: barHeight)
        .padding(.horizontal, 18)
        .background(
            RoundedRectangle(cornerRadius: barCorner, style: .continuous)
                .fill(bg)
        )
        .overlay(
            RoundedRectangle(cornerRadius: barCorner, style: .continuous)
                .stroke(stroke, lineWidth: 1)
        )
        .shadow(color: shadow, radius: 18, x: 0, y: 10)
        .contentShape(RoundedRectangle(cornerRadius: barCorner, style: .continuous))
        .allowsHitTesting(true)
    }

    private func barButton(icon: String, isActive: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 26, weight: .semibold))
                .frame(width: 56, height: 56)
                .foregroundStyle(isActive ? Color.primary : Color.primary.opacity(0.55))
        }
        .buttonStyle(.plain)
    }

    // MARK: - Theme

    private var cs: ColorScheme {
        switch settings.theme {
        case .system:
            return envScheme
        case .light:
            return .light
        case .dark:
            return .dark
        }
    }

    private var appBackground: Color {
        cs == .light ? .white : .black
    }
}
