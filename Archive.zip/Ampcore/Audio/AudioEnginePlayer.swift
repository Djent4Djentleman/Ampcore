import Foundation
import AVFoundation
import Combine

// MARK: - Shared EQ model

struct EQBand: Identifiable, Hashable {
    let id: UUID
    var label: String
    var value: Float
    var min: Float
    var max: Float

    init(id: UUID = UUID(), label: String, value: Float, min: Float, max: Float) {
        self.id = id
        self.label = label
        self.value = value
        self.min = min
        self.max = max
    }
}

final class AudioEnginePlayer: ObservableObject {

    // MARK: - Public state
    @Published var isPlaying = false
    @Published var currentTime: Double = 0
    @Published var duration: Double = 0

    @Published var eqEnabled: Bool = false {
        didSet { updateEQState() }
    }

    // EQ bands are owned by the player so UI can bind safely.
    @Published var eqBands: [EQBand] = AudioEnginePlayer.defaultBands()

    // MARK: - Engine
    private let engine = AVAudioEngine()
    private let playerNode = AVAudioPlayerNode()
    private let mainMixer: AVAudioMixerNode
    private let eqNode = AVAudioUnitEQ(numberOfBands: 10)

    // MARK: - Gain
    private let baseHeadroomDb: Float = -6.0

    init() {
        mainMixer = engine.mainMixerNode
        setupEngine()
    }

    // MARK: - Setup

    private func setupEngine() {
        engine.attach(playerNode)
        engine.attach(eqNode)

        engine.connect(playerNode, to: eqNode, format: nil)
        engine.connect(eqNode, to: mainMixer, format: nil)

        configureEQFromBands()

        eqNode.bypass = true
        mainMixer.outputVolume = dbToLinear(baseHeadroomDb)

        try? engine.start()
    }

    // MARK: - EQ

    private func updateEQState() {
        eqNode.bypass = !eqEnabled
        applyHeadroom()
    }

    func applyEQBands(_ bands: [EQBand]) {
        eqBands = bands
        configureEQFromBands()
        applyHeadroom()
    }

    private func configureEQFromBands() {
        // Short English notes only
        // Map first 10 bands to AVAudioUnitEQ bands
        let count = min(eqBands.count, eqNode.bands.count)
        for i in 0..<count {
            let src = eqBands[i]
            let b = eqNode.bands[i]
            b.bypass = false
            b.filterType = (i == 0) ? .parametric : .parametric
            b.gain = src.value
            b.bandwidth = 1.0
            b.frequency = defaultFrequency(for: i)
        }
    }

    private func applyHeadroom() {
        guard eqEnabled else {
            mainMixer.outputVolume = dbToLinear(baseHeadroomDb)
            return
        }

        // Headroom auto-compensation based on max positive boost.
        let maxBoostDb = eqBands.map { Swift.max(0, $0.value) }.max() ?? 0
        let compensationDb: Float = (maxBoostDb > 0) ? -maxBoostDb : 0
        mainMixer.outputVolume = dbToLinear(baseHeadroomDb + compensationDb)
    }

    private func defaultFrequency(for index: Int) -> Float {
        // Pre + 9 bands (Poweramp-ish)
        switch index {
        case 0: return 0      // Pre (not used by EQ node freq)
        case 1: return 31
        case 2: return 62
        case 3: return 125
        case 4: return 250
        case 5: return 500
        case 6: return 1000
        case 7: return 2000
        case 8: return 4000
        case 9: return 8000
        default: return 1000
        }
    }

    private static func defaultBands() -> [EQBand] {
        [
            .init(label: "Pre", value: 0, min: -12, max: 12),
            .init(label: "31", value: 0, min: -12, max: 12),
            .init(label: "62", value: 0, min: -12, max: 12),
            .init(label: "125", value: 0, min: -12, max: 12),
            .init(label: "250", value: 0, min: -12, max: 12),
            .init(label: "500", value: 0, min: -12, max: 12),
            .init(label: "1K", value: 0, min: -12, max: 12),
            .init(label: "2K", value: 0, min: -12, max: 12),
            .init(label: "4K", value: 0, min: -12, max: 12),
            .init(label: "8K", value: 0, min: -12, max: 12)
        ]
    }

    // MARK: - Fade

    func play() {
        fadeIn()
        isPlaying = true
    }

    func stop() {
        fadeOut {
            self.playerNode.stop()
            self.isPlaying = false
        }
    }

    private func fadeIn() {
        mainMixer.outputVolume = 0
        let target = dbToLinear(baseHeadroomDb)
        rampVolume(to: target)
    }

    private func fadeOut(completion: @escaping () -> Void) {
        rampVolume(to: 0, completion: completion)
    }

    private func rampVolume(to value: Float, duration: TimeInterval = 0.25, completion: (() -> Void)? = nil) {
        let steps = 30
        let start = mainMixer.outputVolume
        let delta = (value - start) / Float(steps)

        for i in 0..<steps {
            DispatchQueue.main.asyncAfter(deadline: .now() + duration * Double(i) / Double(steps)) {
                self.mainMixer.outputVolume = start + delta * Float(i)
                if i == steps - 1 {
                    completion?()
                }
            }
        }
    }

    // MARK: - Utils

    private func dbToLinear(_ db: Float) -> Float {
        pow(10, db / 20)
    }
}
